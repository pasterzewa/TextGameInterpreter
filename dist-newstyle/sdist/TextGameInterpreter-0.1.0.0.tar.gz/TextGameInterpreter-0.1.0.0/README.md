# TextGameInterpreter
